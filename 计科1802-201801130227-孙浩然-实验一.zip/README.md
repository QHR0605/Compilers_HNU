__scan.c__ 程序文件

使用宏定义选择测试文件:
```c
// 启用正例pos.tny
#define TEST_POS
// 启用反例neg1.tny
#define TEST_NEG1
// 启用反例neg2.tny
#define TEST_NEG2
```
仅能声明一个

__out__ 输出结果